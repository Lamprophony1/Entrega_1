
const products = [
  {
    id: 1,
    name: 'Laptop Gamer',
    brand: 'Dell',
    company: 'Cellshop',
    category: 'Electrónica',
    description: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Corrupti suscipit assumenda amet a quis ipsum exercitationem repellat impedit nemo. Odit nobis modi provident accusamus sunt expedita amet fuga quibusdam quia.',
    price: 1500,
    image: '/public/laptop.png',
  },
  {
    id: 2,
    name: 'Mouse Inalámbrico',
    brand: 'Logitech',
    company: 'Nissei',
    category: 'Accesorios',
    description: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Corrupti suscipit assumenda amet a quis ipsum exercitationem repellat impedit nemo.',
    price: 25,
    image: '/public/mouse.png',
  },
  
];
export default products;